<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\users\UsersController;
use App\Http\Controllers\Api\V1\dashboard\DashboardController;
use App\Http\Controllers\Api\V1\loans\LoansController;
use App\Http\Controllers\Api\V1\precautions\PrecautionsController;
use App\Http\Controllers\Api\V1\barrio\BarrioController;

Route::prefix('v1')->group(callback: function () {

    Route::apiResource('users', UsersController::class);
    Route::post('updateUser', [UsersController::class, 'updateUser']);
    Route::get('get-user-data/{id}', [UsersController::class, 'getUserData']);
    Route::get('showCobrador/{id}', [UsersController::class, 'showCobrador']);

    Route::apiResource('side-menu', DashboardController::class);

    Route::apiResource('loans/register', LoansController::class);
    Route::post('loans/getLoansCobrador', [LoansController::class, 'getLoansCobrador']);
    Route::get('loans/recomendacion/{id}', [LoansController::class, 'getRecomendacion']);
    Route::get('loans/cobrador/{id}', [LoansController::class, 'getCobrador']);
    Route::post('list-customer-filter', [LoansController::class, 'getCustomerFilters']);
    Route::get('list-user-customer/{id}', [LoansController::class, 'getUserCustomer']);
    Route::get('list-loader/{id}', [LoansController::class, 'edit']);

    Route::apiResource('precautions', PrecautionsController::class);
    Route::post('precautions-lis-filter', [PrecautionsController::class, 'listPrecautions']);

    Route::post('pay-cuota', [PrecautionsController::class, 'payCuota']);
    Route::post('pay-intereses', [PrecautionsController::class, 'payInterese']);
    Route::post('pay-abono-credit', [PrecautionsController::class, 'payAbono']);
    Route::post('pay-total-credit', [PrecautionsController::class, 'payTotal']);

    Route::apiResource('barrio', BarrioController::class);

});
