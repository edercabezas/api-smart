<?php

namespace App\Enums;

enum PersonGender: string {
    case FEMENINO = 'FEMENINO';
    case MASCULINO = 'MASCULINO';
    case OTROS = 'OTROS';
}
