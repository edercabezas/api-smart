<?php

namespace App\Http\Controllers\Api\V1\barrio;

use App\Http\Controllers\Controller;
use App\Models\ItemLoans;
use App\Models\Loans;
use App\Models\Menu;
use App\Models\User;
use DateTime;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Str;

class BarrioController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $monto_total = 1000000;
        $num_cuotas = 10;
        $monto_cuota = $monto_total / $num_cuotas;
        $fecha_inicio = "30-10-2024";

        $fecha_inicio_obj = DateTime::createFromFormat('d-m-Y', $fecha_inicio);

        $pagos = [];


        for ($i = 1; $i < $num_cuotas; $i++) {
            $fecha_pago = clone $fecha_inicio_obj;
            $dias_a_sumar = $i * 15;
            $fecha_pago->modify("+$i * 15 days");

            $pagos[] = [
                "fecha" => $fecha_pago->format('d-m-Y'),
                "monto" => $monto_cuota
            ];
        }

        foreach ($pagos as $pago) {
            echo "Fecha de pago: " . $pago['fecha'] . ", Monto de la cuota: " . $pago['monto'] . "\n";
        }
    }

    /**
     * Show the form for creating a new resource.
     */

    public function getUserCustomer(string $id)  {
        $data = User::where('users.id', $id)->get();

        return response()->json([
            "data" => $data[0]
        ]);
    }

    public function getCustomerFilters(Request $request)
    {


        $data = DB::table('users')->select(
            'users.id',
            DB::raw("CONCAT(users.name, '  ' , users.user_last_name_one , ' - ' , users.user_document ) as name_customer"),
        )->where('users.profile_code', $request->all()['code'])
            ->orWhere('users.name', 'like', '%' . $request->all()['search'] . '%')
            ->orWhere('users.user_document', 'like', '%' . $request->all()['search'] . '%')
            ->orderBy('users.user_document')
            ->get();
        return response()->json([
            "data" => $data
        ]);

    }

    public function create()
    {
        var_dump('ksadjbkasjbdkbjaskjbd');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $keyItem = 1;
        try {
            DB::beginTransaction();
            $header = $request->all()['loans'];
            $detail = $request->all()['detail'];

//            return response()->json([
//                "data" => $detail['status']
//            ]);
//

            $dataLoans = Loans::create($header);




            if ($dataLoans) {
                $valueLoans = $header['loans_valor_prestado'];
                $interesesLoans = ($header['loans_valor_prestado'] * $header['loans_intereses']) / 100;
                $cuotasLoans = $header['loans_cuotas'];
                $resultCuota = $valueLoans /  $cuotasLoans;


                    for ($i = 1; $i <= $cuotasLoans; $i++ ) {
                        $itemLoans = new ItemLoans();
                        $itemLoans->loans_codigo = $dataLoans->id;
                        $itemLoans->itemloans_cuota = $keyItem;
                        $itemLoans->itemloans_valor_cuota = $resultCuota;
                        $itemLoans->itemloans_iteres = ($interesesLoans / 12);
                        $itemLoans->itemloans_status = $detail['status'];
                        $itemLoans->itemloass_observacion = $detail['observacion'];
                        $itemLoans->itemloans_fecha_pago = $detail['fecha_pago'];
                        $itemLoans->itemloans_aprobador = $detail['aprobador'];
                        $itemLoans->save();

                        $keyItem = $keyItem + 1;
                    }


//

            }

            DB::commit();

            $dataLoans->save();
            return response()->json([
                "response" => 'Registro creado exitosamente',
                'id' => $dataLoans->id
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {

        $data = User::where('users.profile_code', $id)
            ->orderBy('users.created_at')
            ->get();

        return response()->json([
            "data" => $data
        ]);

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {

       $data = Loans::where('id', $id)->orderBy('id')->orderBy('loans.id', 'DESC')->first();
        $item = ItemLoans::where('loans_codigo', $id)->orderBy('item_loans.id', 'ASC')->get();

        return response()->json([
            "result" => ["data" =>$data, "items" => $item],
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
