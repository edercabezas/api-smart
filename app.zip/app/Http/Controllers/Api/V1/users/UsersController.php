<?php

namespace App\Http\Controllers\Api\V1\users;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Str;
class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = User::all();

        return response()->json([
            "data" => $data
        ]);

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        try {
            DB::beginTransaction();

            $clave = '123456789';
            $request['password'] = bcrypt($clave);
            $request['verified'] = 0;
            $request['verification_token'] = Str::random(60);

            $user = new User($request->all());

            $user->save();

            DB::commit();

            return response()->json([
                "response" => 'El registro fue creado exitosamente',
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            return response()->json([
                "response" => 'Error al crear el registro',
            ]);
        }


    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $data = User::find($id);

        return response()->json([
            "user" => $data
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        return response()->json([
            "user" => $request->all()
        ]);
    }

    public function updateUser(Request $request)
    {

        try {
            DB::beginTransaction();

            $user = User::find($request->all()['id']);

             $user->update($request->all());


            DB::commit();

            return response()->json([
                "response" => 'El registro fue actualizado exitosamente',
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            return response()->json([
                "response" => 'Error al actualizar el registro',
            ]);
        }

    }

    public function getUserData(string $id) {

        $data = DB::select("
                     SELECT users.name, users.user_alias, profile.profile_name
                        FROM users
                        INNER JOIN profile ON users.profile_code = profile.id
                        WHERE users.profile_code = $id;
                            ");

        return response()->json([
            "data" => $data[0],
        ]);
    }


    public function showCobrador(string $id)
    {
        $data = DB::table('users')
            ->select('id',
                'name',
                'profile_code',
                'remember_token',
                'user_address',
                'user_age',
                'user_alias',
                'user_birth',
                'user_cellphone',
                'user_city',
                'user_document',
                'user_document_type',
                'user_last_name_one',
                'user_last_name_two',
                'user_neighborhood'
       )->where('profile_code', $id)
        ->get();

        return response()->json([
            "data" => $data,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
