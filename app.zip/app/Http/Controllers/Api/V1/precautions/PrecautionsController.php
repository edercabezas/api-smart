<?php

namespace App\Http\Controllers\Api\V1\precautions;

use App\Http\Controllers\Controller;
use App\Models\ItemLoans;
use App\Models\Loans;
use App\Models\Menu;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Str;
use DateTime;
class PrecautionsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $fechaActual = Carbon::now();
        $formatDate = $fechaActual->format( 'd-m-Y');


        $data = DB::table('loans as l')
            ->select(DB::raw("
        EXTRACT(DAY FROM (
            CASE
                WHEN l.loans_cuando = 'D' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '1 day'
                WHEN l.loans_cuando = 'S' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '1 week'
                WHEN l.loans_cuando = 'Q' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '2 weeks'
                WHEN l.loans_cuando = 'M' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '1 month'
                WHEN l.loans_cuando = 'T' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '3 months'
                ELSE NULL
            END
            - CURRENT_DATE
        )) as dias_faltantes
    "),DB::raw("
        (
            CASE
                WHEN l.loans_cuando = 'D' THEN 'Diario'
                WHEN l.loans_cuando = 'S' THEN 'Semanal'
                WHEN l.loans_cuando = 'Q' THEN 'Quinsenal'
                WHEN l.loans_cuando = 'M' THEN 'Mensual'
                WHEN l.loans_cuando = 'T' THEN 'Trimestral'
                ELSE NULL
            END
        ) as frecuencia_pago
    "), 'l.id',
                'l.loans_documento',
                'l.loans_nombre',
                'l.loans_apellido_uno',
                'l.loans_fecha',
                'l.loans_valor_prestado',
                'l.loans_cuotas',
                'l.loans_estado',
                'l.loans_intereses',
                'uco.name as cobrador',
                'l.loans_fecha_ultimo_pago',
                'l.loans_cuando',
                'ure.name as recomendador')
            ->join('users as ucl', 'l.user_customer', '=', 'ucl.id')
            ->join('users as uco', 'l.user_cobrador', '=', 'uco.id')
            ->join('users as ure', 'l.user_recomendacion', '=', 'ure.id')

            ->orderBy('l.id', 'desc')
            ->get();
        return response()->json([
            "data" => $data
        ]);


    }

    public function listPrecautions(Request $request) {
        $fechaActual = Carbon::now();
        $formatDate = $fechaActual->format( 'd-m-Y');

//
//        return response()->json([
//            "data" => $request->all()
//        ]);
        $cobrador = $request->all()['cobrador'];
        $estado = $request->all()['estado'];
        $frecuencia = $request->all()['frecuencia'];
        $prestamista = $request->all()['prestamista'];


        $data = DB::table('loans as l')
            ->select(DB::raw("
        EXTRACT(DAY FROM (
            CASE
                WHEN l.loans_cuando = 'D' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '1 day'
                WHEN l.loans_cuando = 'S' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '1 week'
                WHEN l.loans_cuando = 'Q' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '2 weeks'
                WHEN l.loans_cuando = 'M' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '1 month'
                WHEN l.loans_cuando = 'T' AND (l.loans_estado = 'Pendiente' OR l.loans_estado = 'En curso') THEN l.loans_fecha_ultimo_pago::date + INTERVAL '3 months'
                ELSE NULL
            END
            - CURRENT_DATE
        )) as dias_faltantes
    "),DB::raw("
        (
            CASE
                WHEN l.loans_cuando = 'D' THEN 'Diario'
                WHEN l.loans_cuando = 'S' THEN 'Semanal'
                WHEN l.loans_cuando = 'Q' THEN 'Quinsenal'
                WHEN l.loans_cuando = 'M' THEN 'Mensual'
                WHEN l.loans_cuando = 'T' THEN 'Trimestral'
                ELSE NULL
            END
        ) as frecuencia_pago
    "), 'l.id',
                'l.loans_documento',
                'l.loans_nombre',
                'l.loans_apellido_uno',
                'l.loans_fecha',
                'l.loans_valor_prestado',
                'l.loans_cuotas',
                'l.loans_estado',
                'l.loans_intereses',
                'uco.name as cobrador',
                'l.loans_fecha_ultimo_pago',
                'l.loans_cuando',
                'ure.name as recomendador')
            ->join('users as ucl', 'l.user_customer', '=', 'ucl.id')
            ->join('users as uco', 'l.user_cobrador', '=', 'uco.id')
            ->join('users as ure', 'l.user_recomendacion', '=', 'ure.id')

            ->when($cobrador, function ($query) use ($cobrador) {
                return $query->where('l.user_cobrador', $cobrador );
            })
            ->when($estado, function ($query) use ($estado) {
                return $query->where('l.loans_estado', $estado);
            })
            ->when($frecuencia, function ($query) use ($frecuencia) {
                return $query->where('l.loans_cuando', $frecuencia);
            })
            ->when($prestamista, function ($query) use ($prestamista) {
                return $query->where('l.user_creador', $prestamista);
            })
            ->orderBy('l.id', 'desc')
            ->get();

        return response()->json([
            "data" => $data
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */

    public function getUserCustomer(string $id)  {
        $data = User::where('users.id', $id)->get();

        return response()->json([
            "data" => $data[0]
        ]);
    }

    public function getCustomerFilters(Request $request)
    {


        $data = DB::table('users')->select(
            'users.id',
            DB::raw("CONCAT(users.name, '  ' , users.user_last_name_one , ' - ' , users.user_document ) as name_customer"),
        )->where('users.profile_code', $request->all()['code'])
            ->orWhere('users.name', 'like', '%' . $request->all()['search'] . '%')
            ->orWhere('users.user_document', 'like', '%' . $request->all()['search'] . '%')
            ->orderBy('users.user_document')
            ->get();
        return response()->json([
            "data" => $data
        ]);

    }

    public function create()
    {
        var_dump('ksadjbkasjbdkbjaskjbd');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $keyItem = 1;
        try {
            DB::beginTransaction();
            $header = $request->all()['loans'];
            $detail = $request->all()['detail'];

//            return response()->json([
//                "data" => $detail['status']
//            ]);
//

            $dataLoans = Loans::create($header);




            if ($dataLoans) {
                $valueLoans = $header['loans_valor_prestado'];
                $interesesLoans = ($header['loans_valor_prestado'] * $header['loans_intereses']) / 100;
                $cuotasLoans = $header['loans_cuotas'];
                $resultCuota = $valueLoans /  $cuotasLoans;


                    for ($i = 1; $i <= $cuotasLoans; $i++ ) {
                        $itemLoans = new ItemLoans();
                        $itemLoans->loans_codigo = $dataLoans->id;
                        $itemLoans->itemloans_cuota = $keyItem;
                        $itemLoans->itemloans_valor_cuota = $resultCuota;
                        $itemLoans->itemloans_iteres = ($interesesLoans / 12);
                        $itemLoans->itemloans_status = $detail['status'];
                        $itemLoans->itemloass_observacion = $detail['observacion'];
                        $itemLoans->itemloans_fecha_pago = $detail['fecha_pago'];
                        $itemLoans->save();

                        $keyItem = $keyItem + 1;
                    }


//

            }

            DB::commit();

            $dataLoans->save();
            return response()->json([
                "response" => 'Registro creado exitosamente',
                'id' => $dataLoans->id
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
        }
    }

    /**
     * Display the specified resource.
     */

    public function createPass(Request $request)
    {

        $formatOperation = null;
        $fechaActual = Carbon::now();
        $keyItem = 1;
        try {
            DB::beginTransaction();
            $header = $request->all()['loans'];
            $detail = $request->all()['detail'];


            $formatDate = $fechaActual->format( $header['loans_inicio_pago']);
            $header['loans_fecha'] = $formatDate;

//            $dataLoans = Loans::where('loans.id', $id);

           $dataLoans = Loans::create($header);

            if ($dataLoans) {
                $valueLoans = $header['loans_valor_prestado'];
                $interesesLoans = ($header['loans_valor_prestado'] * $header['loans_intereses']) / 100;
                $cuotasLoans = $header['loans_cuotas'];
                $resultCuota = $valueLoans /  $cuotasLoans;

                $fechaInicio = DateTime::createFromFormat('d-m-Y', $formatDate);

                for ($i = 1; $i <= $cuotasLoans; $i++ ) {

                    $fechaPago = clone $fechaInicio;
                    $itemLoans = new ItemLoans();

                    switch ($header['loans_cuando']) {
                        case 'D':
                            $fechaPago->modify("+$i days"); //Diario
                            break;

                        case 'S':
                            $formatOperation = $i * 8;
                            $fechaPago->modify("+$formatOperation days"); // Semanal
                            break;

                        case 'Q':
                            $formatOperation = $i * 16;
                            $fechaPago->modify("+$formatOperation days"); // Quinsenal
                            break;

                        case 'M':
                            $formatOperation = $i * 30;
                            $fechaPago->modify("+$formatOperation days"); //Mensual
                            break;

                        default:
                            $formatOperation = $i * 90;
                            $fechaPago->modify("+$formatOperation days"); // trimestral
                            break;
                    }


                    $itemLoans->loans_codigo = $dataLoans->id;
                    $itemLoans->itemloans_cuota = $keyItem;
                    $itemLoans->itemloans_valor_cuota = $resultCuota;
                    $itemLoans->itemloans_iteres = ($interesesLoans / $header['loans_cuotas']);
                    $itemLoans->itemloans_status = $detail['status'];
                    $itemLoans->itemloass_observacion = $detail['observacion'];
                    $itemLoans->itemloans_fecha_pago = $fechaPago->format('d-m-Y');
                    $itemLoans->itemloans_aprobador = $detail['aprobador'];
                    $itemLoans->save();

                    $keyItem = $keyItem + 1;
                }
            }

            DB::commit();

            $dataLoans->save();
            return response()->json([
                "response" => 'Registro creado exitosamente',
                'id' => $dataLoans->id
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
        }

    }
        public function show(string $id)
    {

        $data = DB::select("
                            select l.id,
                                uco.name as cobrador,
                                ure.name as recomendador,
                                l.loans_nombre,
                                l.loans_apellido_uno,
                                l.loans_apellido_dos,
                                l.loans_tipo_documento,
                                l.loans_documento,
                                l.loans_fecha_nacimiento,
                                l.loans_ciudad,
                                l.loans_barrio,
                                l.loans_direccion,
                                l.loans_intereses,
                                l.loans_cuotas,
                                l.loans_valor_prestado,
                                l.loans_cuando,
                                l.loans_observacion,
                                l.loans_fecha,
                                l.loans_estado,
                                l.loans_celular,
                                l.loans_inicio_pago,
                                l.loans_pago_prestado,
                                l.loans_pago_interes,
                                ucr.user_alias
                            from loans l
                            join users ucl on l.user_customer = ucl.id
                            join users ucr on l.user_creador = ucr.id
                            join users uco on l.user_cobrador = uco.id
                            left join users ure on l.user_recomendacion = ure.id
                            where l.id = $id
                        ");

            $item = DB::table('item_loans')
                ->select('item_loans.*', 'users.user_alias') // Selección de columnas
                ->leftJoin('users', 'item_loans.itemloans_aprobador', '=', 'users.id')
                ->where('item_loans.loans_codigo', $id)
                ->orderBy('item_loans.id', 'ASC')
                ->get();

        return response()->json([
            "result" => ["data" =>$data[0], "items" => $item],
        ]);

//        $data = User::where('users.profile_code', $id)
//            ->orderBy('users.created_at')
//            ->get();
//
//        return response()->json([
//            "data" => $data
//        ]);

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {

       $data = Loans::where('id', $id)->orderBy('id')->orderBy('loans.id', 'DESC')->first();
        $item = ItemLoans::where('loans_codigo', $id)->orderBy('item_loans.id', 'ASC')->get();

        return response()->json([
            "result" => ["data" =>$data, "items" => $item],
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function payCuota(Request $request)
    {
        try {
            DB::beginTransaction();
        $mensaje = '';
        $status = false;
        $fechaActual = Carbon::now();
        $formatDate = $fechaActual->format( 'd-m-Y');
        $identificador = $request->all()['id'];
        $loans = $request->all()['loans_codigo'];



        $itemLoans = ItemLoans::find($identificador);
        $loansTable = Loans::find($loans);

        if ($request->all()['itemloans_cuota'] == $loansTable->loans_cuotas) {
            $loansTable->loans_estado = 'Cancelado';
        } else {
            $loansTable->loans_estado = 'En curso';
        }
        $loansTable->loans_pago_prestado = $loansTable->loans_pago_prestado + $request->all()['itemloans_cuota_cancelada'];


//            return response()->json([
//                "message" => $itemLoans
//            ]);

            if ($itemLoans->itemloans_interes_canelado ===0 || $itemLoans->itemloans_interes_canelado == '0') {
                $loansTable->loans_pago_interes = $loansTable->loans_pago_interes + $request->all()['itemloans_interes_canelado'];
            }



        $loansTable->loans_fecha_ultimo_pago = $formatDate;


        if ($itemLoans->itemloans_status == 'Pagada') {
            return response()->json([
                "message" => 'Esta cuota ya se encuentra pagada seleccione la siguiente',
                "status" => $status
            ]);
        }


        $itemLoans->itemloans_cuota_cancelada = $request->all()['itemloans_cuota_cancelada'];

        if ($itemLoans->itemloans_interes_canelado == 0 || $itemLoans->itemloans_interes_canelado == '0') {
            $itemLoans->itemloans_interes_canelado = $request->all()['itemloans_interes_canelado'];
        }
        $itemLoans->itemloans_status = 'Pagada';
        $itemLoans->item_loans_cuando_pago = $formatDate;
        $itemLoans->itemloans_aprobador = $request->all()['itemloans_aprobador'];

            DB::commit();


            if ($itemLoans->save()) {
                $mensaje = 'El pago fue realizado exitosamente';
                $status = true;
            } else {
                $mensaje = 'En estos momentos nos e puede realizar el pago intentelo mas tarde';
                $status = false;
            }

            $loansTable->save();

            return response()->json([
                "message" => $mensaje,
                "status" => $status
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            return response()->json([
                "message" => 'Hubo un error al realizar el pago intentelo mas tarde',
                "status" => false
            ]);
        }

    }

    public function payInterese(Request $request)
    {
        try {
            DB::beginTransaction();
            $mensaje = '';
            $status = false;
            $fechaActual = Carbon::now();
            $formatDate = $fechaActual->format( 'd-m-Y');
            $identificador = $request->all()['id'];
            $loans = $request->all()['loans_codigo'];



            $itemLoans = ItemLoans::find($identificador);
            $loansTable = Loans::find($loans);
            $loansTable->loans_fecha_ultimo_pago = $formatDate;
            $loansTable->loans_pago_interes = $loansTable->loans_pago_interes + $request->all()['itemloans_interes_canelado'];
            $loansTable->loans_estado = 'En curso';

            if ($itemLoans->itemloans_status == 'Pagada') {
                return response()->json([
                    "message" => 'Esta cuota ya se encuentra pagada seleccione la siguiente',
                    "status" => $status
                ]);
            }


            $itemLoans->itemloans_cuota_cancelada = 0;
            $itemLoans->itemloans_interes_canelado = $request->all()['itemloans_interes_canelado'];
            $itemLoans->itemloans_status = 'Abono intereses';
            $itemLoans->item_loans_cuando_pago = $formatDate;
            $itemLoans->itemloans_aprobador = $request->all()['itemloans_aprobador'];

            DB::commit();


            if ($itemLoans->save()) {
                $mensaje = 'El abono a intereses  de la cuota fue aplicado exitosamente';
                $status = true;
            } else {
                $mensaje = 'En estos momentos nos e puede realizar el abono a intereses intentelo mas tarde';
                $status = false;
            }

            $loansTable->save();

            return response()->json([
                "message" => $mensaje,
                "status" => $status
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            return response()->json([
                "message" => 'Hubo un error al realizar el pago de intereses intentelo mas tarde',
                "status" => false
            ]);
        }
    }

    public function payAbono(Request $request)
    {

        $keyItem = 0;
        try {
            DB::beginTransaction();

            $fechaActual = Carbon::now();
            $formatDate = $fechaActual->format( 'd-m-Y');

            $idLoans = $request->all()['idLoans'];
            $valorAbono = +$request->all()['valueAbono'];
            $idCreador = +$request->all()['itemloans_aprobador'];
//        $itemLoans = ItemLoans::find($identificador);
            $loansTable = Loans::find($idLoans);
            //Obtengo la ganancia por este credito



            if ($loansTable->loans_estado == 'Cancelado') {
                return response()->json([
                    "message" => 'Este credito ya se encuentra pagado y no se puede modificar',
                    "status" => false
                ]);
            }


            $interesePesos = $loansTable->loans_valor_prestado * $loansTable->loans_intereses / 100;

            //Ahora le sumo la ganancia a al valor prestado
            $recaudoTotal = $loansTable->loans_valor_prestado + $interesePesos;

            //Ahora debo sumar lo que ha pagado hasta el momento el cliente sumando pago de intereses y valor de la cuota
            $canceladoHastaLaFecha = $loansTable->loans_pago_prestado + $loansTable->loans_pago_interes;

            //Ahora debo restar el valor a recaudar menos lo que ya ha pagado el cliente
            $valorPorPagar = $recaudoTotal - $canceladoHastaLaFecha;

            // debo obtener el interes que resta por pagar
            $interesPorCancelar = $interesePesos - $loansTable->loans_pago_interes;

            // ahora debo otener el valor restante por pagar osea el valor que preste sin intereces
            $valorSinInteresPorPagar = $loansTable->loans_valor_prestado - $loansTable->loans_pago_prestado;
            //Ahora debo hacer una condicion para no permitir que abone mas de lo que debe el cliente

            if ($valorAbono > $valorPorPagar) {
                return response()->json([
                    "message" => "El valor a abonar supera el valor de la deuda que es actualmente de $valorPorPagar",
                    "status" => false
                ]);
            }

            //Hag una división del capital restante sobre el valor a cancelar total con los intereses y esto em da un porcentaje
            $dividirCapitalporvalorPagar = $valorSinInteresPorPagar / $valorPorPagar;

            //Aqui resto los intereses restante sobre el valor por pagar total y esto me da un porcentaje
            $dividirInteresPorValorPagar = $interesPorCancelar / $valorPorPagar;

            //Ahora voy a ver del valor a abonar cuanto es para los intereses y cuanto es para el capital

            //Primero para saber cuanto va hacia el capital

            $abonoParaCapital = $valorAbono*$dividirCapitalporvalorPagar;
            $abonoParaInteres = $valorAbono*$dividirInteresPorValorPagar;



            /**
             * Necesito validar cuantas cuotas cuotas hay pendientes antes de borrarlas para poder crearla con el nuevo saldo que queda
             */

            $conteoRegistrosPagos = ItemLoans::where('loans_codigo', $idLoans)
                ->where(function ($query){
                $query->where('itemloans_status', 'Pagada')
                    ->orWhere('itemloans_status', 'Abono');
            }) ->count() + 1;


            /**
             * este contador sera el encargadod e indicarme cual es el numero de cuota que sigue sumandole uno mas a las cuotas que ya estan pagadas ejemplo
             * hay 3 cuotas pagadas el contador debe ser igual a cuotas pagadas mas 1
             */
            $keyItem = $conteoRegistrosPagos + 1;
            /**
             * Resto a la cantidad de cuotas el numero de cuota que se pagaron actualmente y me da la cantidad de cuotas que debo dividir el nuevo valor
             */
            $resultadoConteo =  $loansTable->loans_cuotas - $conteoRegistrosPagos;




            if ($resultadoConteo == 1 || $resultadoConteo == '1') {
                $resultadoConteo = 0;
                $loansTable->loans_estado = 'Cancelado';
                if ($valorAbono < $valorPorPagar) {
                    return response()->json([
                        "message" => "Es la ultima cuota del credito no se puede realizar abono, realiza el pago total de la cuota",
                        "status" => false
                    ]);
                }

            } else {
                $loansTable->loans_estado = 'En curso';
            }

            /**
             * Actualizar los valores de loans
             */


            $loansTable->loans_pago_interes += $abonoParaInteres;
            $loansTable->loans_pago_prestado += $abonoParaCapital;
            $loansTable->loans_fecha_ultimo_pago = $formatDate;

            $loansTable->save();

            /**
             * Listo unicamente el priemr registro de ese credito de estado pendiente apra poder actualizarlo con los nuevos datos
             */
            $listItme = ItemLoans::where('loans_codigo', $idLoans)
                ->where('itemloans_status', 'Pendiente')
                ->first();

            if ($listItme) {
                $listItme->itemloans_interes_canelado = $abonoParaInteres;
                $listItme->itemloans_cuota_cancelada = $abonoParaCapital;
                $listItme->itemloans_status = 'Abono';
                $listItme->item_loans_cuando_pago = $formatDate;
                $listItme->itemloans_aprobador = $request->all()['itemloans_aprobador'];
                $listItme->save();
            }

            /**
             * Borro los registro que estan pendientes despues de actualizar el pago con el abono y ponerlo en estado pagado
             */
            ItemLoans::where('loans_codigo', $idLoans)
                ->where('itemloans_status', 'Pendiente')->delete();


            $loansValueFinal = Loans::find($idLoans);
            $restaValorCapital = $loansValueFinal->loans_valor_prestado - $loansValueFinal->loans_pago_prestado;
            $restaInteresCapital = $loansValueFinal->loans_intereses_recaudar - $loansValueFinal->loans_pago_interes;


//            if ($conteoRegistrosPagos === 0) {
//                $resultadoConteo -= 1;
//                $keyItem = 2;
//            }

            if ($resultadoConteo > 0) {
                $fechaInicio = DateTime::createFromFormat('d-m-Y', $formatDate);

                for ($i = 1; $i <= $resultadoConteo; $i++ ) {

                    $fechaPago = clone $fechaInicio;
                    $itemLoans = new ItemLoans();

                    switch ($loansTable->loans_cuando) {
                        case 'D':
                            $fechaPago->modify("+$i days"); //Diario
                            break;

                        case 'S':
                            $formatOperation = $i * 8;
                            $fechaPago->modify("+$formatOperation days"); // Semanal
                            break;

                        case 'Q':
                            $formatOperation = $i * 16;
                            $fechaPago->modify("+$formatOperation days"); // Quinsenal
                            break;

                        case 'M':
                            $formatOperation = $i * 30;
                            $fechaPago->modify("+$formatOperation days"); //Mensual
                            break;

                        default:
                            $formatOperation = $i * 90;
                            $fechaPago->modify("+$formatOperation days"); // trimestral
                            break;
                    }


                    $itemLoans->loans_codigo = $idLoans;
                    $itemLoans->itemloans_cuota = $keyItem;
                    $itemLoans->itemloans_valor_cuota = $restaValorCapital / $resultadoConteo;
                    $itemLoans->itemloans_iteres = $restaInteresCapital / $resultadoConteo;
                    $itemLoans->itemloans_status = 'Pendiente';
                    $itemLoans->itemloass_observacion = 'Se realiza abono';
                    $itemLoans->itemloans_fecha_pago = $fechaPago->format('d-m-Y');
                    $itemLoans->itemloans_interes_canelado = 0;
                    $itemLoans->itemloans_cuota_cancelada = 0;


                    $itemLoans->save();

                    $keyItem += 1;
                }
            }


            DB::commit();

            return response()->json([
                "message" => 'El abono fue aplicado exitosamente',
                "status" => true
            ]);


        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            return response()->json([
                "message" => 'Hubo un error al realizar el abono intentelo mas tarde',
                "status" => false
            ]);
        }




    }

    public function payTotal(Request $request)
    {

        try {
            DB::beginTransaction();

            $fechaActual = Carbon::now();
            $formatDate = $fechaActual->format( 'd-m-Y');

            $idLoans = $request->all()['idLoans'];
            $loansTable = Loans::find($idLoans);



            if ($loansTable->loans_estado == 'Cancelado') {
                return response()->json([
                    "message" => 'Este credito ya se encuentra pagado y no se puede modificar',
                    "status" => false
                ]);
            }


            //Obtengo la ganancia por este credito
            $interesePesos = $loansTable->loans_valor_prestado * $loansTable->loans_intereses / 100;

            /**
             * Actualizar los valores de loans
             */


            $loansTable->loans_pago_prestado = $loansTable->loans_valor_prestado;
            $loansTable->loans_pago_interes = $interesePesos;
            $loansTable->loans_fecha_ultimo_pago = $formatDate;
            $loansTable->loans_estado = 'Cancelado';

            $loansTable->save();


            $listItme = ItemLoans::where('loans_codigo', $idLoans)
                ->where('itemloans_status', 'Pendiente')
                ->first();

//            return response()->json([
//                "message" => $listItme->itemloans_iteres
//            ]);

            if ($listItme) {
                ItemLoans::where('loans_codigo', $idLoans)
                    ->where('itemloans_status', 'Pendiente')
                    ->update([
                        'itemloans_interes_canelado' => $listItme->itemloans_iteres,
                        'itemloans_cuota_cancelada' => $listItme->itemloans_valor_cuota,
                        'item_loans_cuando_pago' => $formatDate,
                        'itemloans_status' => 'Pagada',
                        'itemloans_aprobador' => +$request->all()['itemloans_aprobador']
                    ]);
            }



            DB::commit();

            return response()->json([
                "message" => 'Se ha realizado el pago total del credito',
                "status" => true
            ]);


        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            return response()->json([
                "message" => 'Hubo un error al realizar el abono intentelo mas tarde',
                "status" => false
            ]);
        }

    }
    public function refinanciar(Request $request)
    {

    }

    public function anularCuota(Request $request)
    {

    }

}
