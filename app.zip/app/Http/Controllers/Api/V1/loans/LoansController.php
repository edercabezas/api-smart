<?php

namespace App\Http\Controllers\Api\V1\loans;

use App\Http\Controllers\Controller;
use App\Models\ItemLoans;
use App\Models\Loans;
use App\Models\Menu;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Str;
use DateTime;
use Carbon\Carbon;
use function Laravel\Prompts\select;

class LoansController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = DB::select("
                            select l.id,
                                l.loans_documento,
                                l.loans_nombre,
                                l.loans_apellido_uno,
                                l.loans_fecha,
                                l.loans_valor_prestado,
                                l.loans_cuotas,
                                l.loans_estado,
                                l.loans_intereses,
                                uco.name as cobrador,
                                ure.name as recomendador
                            from loans l
                            join users ucl on l.user_customer = ucl.id
                            join users uco on l.user_cobrador = uco.id
                            left join users ure on l.user_recomendacion = ure.id
                             order by l.id DESC
                        ");

        return response()->json([
            "data" => $data
        ]);


    }

    public function getLoansCobrador(Request $request) {

        $cobrador = $request->all()['cobrador'];
        $estado = $request->all()['estado'];
        $frecuencia = $request->all()['frecuencia'];
        $prestamista = $request->all()['prestamista'];

        $data = DB::table('loans as l')
        ->select(   'l.id',
                            'l.loans_documento',
                            'l.loans_nombre',
                            'l.loans_apellido_uno',
                            'l.loans_fecha',
                            'l.loans_valor_prestado',
                            'l.loans_cuotas',
                            'l.loans_estado',
                            'l.loans_intereses',
                            'uco.name as cobrador',
                            'ure.name as recomendador'

                        )
            ->join('users as ucl', 'l.user_customer', '=', 'ucl.id')
            ->join('users as uco', 'l.user_cobrador', '=', 'uco.id')
            ->join('users as ure', 'l.user_recomendacion', '=', 'ure.id')
            ->when($cobrador, function ($query) use ($cobrador) {
                return $query->where('l.user_cobrador', $cobrador );
            })
            ->when($estado, function ($query) use ($estado) {
                return $query->where('l.loans_estado', $estado);
            })
            ->when($frecuencia, function ($query) use ($frecuencia) {
                return $query->where('l.loans_cuando', $frecuencia);
            })
            ->when($prestamista, function ($query) use ($prestamista) {
                return $query->where('l.user_creador', $prestamista);
            })
            ->orderBy('l.id', 'desc')
            ->get();

        return response()->json([
            "data" => $data
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */

    public function getUserCustomer(string $id)  {
        $data = User::where('users.id', $id)->get();

        return response()->json([
            "data" => $data[0]
        ]);
    }

    public function getCustomerFilters(Request $request)
    {

        $search = $request->all()['search'];

        $data = DB::table('users')->select(
            'users.id',
            DB::raw("CONCAT(users.name, '  ' , users.user_last_name_one , ' - ' , users.user_document ) as name_customer"),
        )->where('users.profile_code', $request->all()['code'])->where(function ($query) use ($search){
            $query->where('users.name', 'like', '%' . $search . '%')
                ->orWhere('users.user_document', 'like', '%' . $search . '%');
        })

            ->orderBy('users.user_document')
            ->get();
        return response()->json([
            "data" => $data
        ]);

    }

    public function create()
    {
        var_dump('ksadjbkasjbdkbjaskjbd');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $formatOperation = null;
        $fechaActual = Carbon::now();
        $keyItem = 1;

        try {
            DB::beginTransaction();
            $header = $request->all()['loans'];
            $detail = $request->all()['detail'];


            $intereses = ($header['loans_valor_prestado'] * $header['loans_intereses']) / 100;
            $formatDate = $fechaActual->format( 'd-m-Y' );
            $header['loans_fecha'] = $formatDate;
            $header['loans_fecha_ultimo_pago'] = $formatDate;
            $header['loans_inicio_pago'] = $formatDate;
            $header['loans_intereses_recaudar'] = $intereses;

            $dataLoans = Loans::create($header);

            if ($dataLoans) {
                $valueLoans = $header['loans_valor_prestado'];
                $interesesLoans = $intereses;
                $cuotasLoans = $header['loans_cuotas'];
                $resultCuota = $valueLoans /  $cuotasLoans;

               $fechaInicio = DateTime::createFromFormat('d-m-Y', $formatDate);

                    for ($i = 1; $i <= $cuotasLoans; $i++ ) {

                        $fechaPago = clone $fechaInicio;
                        $itemLoans = new ItemLoans();

                        switch ($header['loans_cuando']) {
                            case 'D':
                                $fechaPago->modify("+$i days"); //Diario
                                break;

                            case 'S':
                                $formatOperation = $i * 8;
                                $fechaPago->modify("+$formatOperation days"); // Semanal
                                break;

                            case 'Q':
                                $formatOperation = $i * 16;
                                $fechaPago->modify("+$formatOperation days"); // Quinsenal
                                break;

                            case 'M':
                                $formatOperation = $i * 30;
                                $fechaPago->modify("+$formatOperation days"); //Mensual
                                break;

                            default:
                                $formatOperation = $i * 90;
                                $fechaPago->modify("+$formatOperation days"); // trimestral
                                break;
                        }


                        $itemLoans->loans_codigo = $dataLoans->id;
                        $itemLoans->itemloans_cuota = $keyItem;
                        $itemLoans->itemloans_valor_cuota = $resultCuota;
                        $itemLoans->itemloans_iteres = ($interesesLoans / $header['loans_cuotas']);
                        $itemLoans->itemloans_status = $detail['status'];
                        $itemLoans->itemloass_observacion = $detail['observacion'];
                        $itemLoans->itemloans_fecha_pago = $fechaPago->format('d-m-Y');
                        $itemLoans->itemloans_aprobador = $detail['aprobador'];
                        $itemLoans->itemloans_interes_canelado = 0;
                        $itemLoans->itemloans_cuota_cancelada = 0;
                        $itemLoans->save();

                        $keyItem = $keyItem + 1;
                    }
            }

            DB::commit();

            $dataLoans->save();
            return response()->json([
                "message" => 'Registro creado exitosamente',
                'id' => $dataLoans->id
            ]);

        } catch (ModelNotFoundException $e) {
            DB::rollBack();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {

        $data = User::where('users.profile_code', $id)
            ->orderBy('users.created_at')
            ->get();

        return response()->json([
            "data" => $data
        ]);

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {

       $data = Loans::where('id', $id)
           ->select(
                'loans_nombre',
                'loans_apellido_uno',
                'loans_apellido_dos',
                'loans_tipo_documento',
                'loans_documento',
                'loans_fecha_nacimiento',
                'loans_ciudad',
                'loans_barrio',
                'loans_direccion',
                'loans_intereses',
                'loans_cuotas',
                'loans_valor_prestado',
                'loans_cuando',
                'loans_observacion',
                'loans_fecha',
                'loans_estado',
                'loans_celular',
                'user_creador',
                'user_cobrador',
                'user_customer',
                'user_recomendacion')
           ->orderBy('id')
           ->orderBy('loans.id', 'DESC')->first();
        $item = ItemLoans::where('loans_codigo', $id)->orderBy('item_loans.id', 'ASC')->get();

        return response()->json([
            "result" => ["data" =>$data, "items" => $item],
        ]);
    }

    public function getRecomendacion(string $id)
    {

        $data = User::where('users.profile_code', '<>', 1)
            ->orderBy('users.created_at')
            ->get();

        return response()->json([
            "data" => $data
        ]);
    }

    public function getCobrador(string $id)
    {
        $data = User::where('users.profile_code', $id)
            ->orderBy('users.created_at')
            ->get();

        return response()->json([
            "data" => $data
        ]);
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
