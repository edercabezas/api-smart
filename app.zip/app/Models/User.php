<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Str;
use Spatie\Permission\Traits\HasRoles;


class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles, SoftDeletes;

    const USER_VERIFIED = '1';
    const USER_NOT_VERIFIED = '0';

    const USER_ADMIN = 'true';
    const USER_REGULAR = 'false';

    protected $dates = ['delete_at'];
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'user_last_name_one',
        'user_last_name_two',
        'user_document_type',
        'user_document',
        'user_birth',
        'user_city',
        'user_neighborhood',
        'user_address',
        'user_cellphone',
        'profile_code',
        'password',
        'verified',
        'user_age',
        'user_alias',
        'verification_token',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'verification_token'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'role_id' => 'int'
    ];

    public function profile()
    {
        return $this->belongsTo('App\Models\Profile', 'profile_code');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function loansCobrador()
    {
        return $this->hasMany('App\Models\Loan', 'user_cobrador');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function loansCreador()
    {
        return $this->hasMany('App\Models\Loan', 'user_creador');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function loansCustomer()
    {
        return $this->hasMany('App\Models\Loan', 'user_customer');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function loansRecomendacion()
    {
        return $this->hasMany('App\Models\Loan', 'user_recomendacion');
    }

    public static function generateVerificationToken()
    {
        return Str::random(40);
    }
}
