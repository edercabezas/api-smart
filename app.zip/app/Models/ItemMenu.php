<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use App\Transformers\V1\Clinic\ClinicTransformer;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Consultorio
 *
 * @property int $id
 * @property int $item_menu_profile
 * @property int $item_menu_menu
 * @property Carbon $created_at
 * @property Carbon $updated_at
 *
 * @property Collection|Doctor[] $doctors
 *
 * @package App\Models
 */
class ItemMenu extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = true;

	protected $table = 'item_menu';
    protected $dates = ['delete_at'];
	protected $fillable = [
		'item_menu_profile',
		'item_menu_menu',
	];

//    public $transformer = ClinicTransformer::class;

	public function profile()
	{
		return $this->belongsTo(Profile::class);
	}

    public function menu()
	{
		return $this->belongsTo(Menu::class);
	}


}
