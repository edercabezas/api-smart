<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use App\Transformers\V1\Clinic\ClinicTransformer;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Consultorio
 *
 * @property int $id
 * @property string $name
 * @property string $address
 * @property string $phone
 * @property Carbon $created_at
 * @property Carbon $updated_at
 *
 * @property Collection|Doctor[] $doctors
 *
 * @package App\Models
 */
class Menu extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = true;

	protected $table = 'menu';
    protected $dates = ['delete_at'];
	protected $fillable = [
		'menu_name',
		'menu_prefix',
		'menu_url',
        'menu_orden'
	];

//    public $transformer = ClinicTransformer::class;



    public function itemMenu()
	{
		return $this->hasMany(ItemMenu::class);
	}


}
