<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property integer $id
 * @property integer $user_creador
 * @property integer $user_recomendacion
 * @property integer $user_customer
 * @property integer $user_cobrador
 * @property string $loans_nombre
 * @property string $loans_apellido_uno
 * @property string $loans_apellido_dos
 * @property string $loans_tipo_documento
 * @property integer $loans_documento
 * @property string $loans_fecha_nacimiento
 * @property string $loans_fecha_ultimo_pago
 * @property string $loans_ciudad
 * @property string $loans_barrio
 * @property string $loans_direccion
 * @property integer $loans_intereses
 * @property integer $loans_cuotas
 * @property integer $loans_intereses_recaudar
 * @property integer $loans_valor_prestado
 * @property integer $loans_inicio_pago
 * @property integer $loans_pago_prestado
 * @property string $loans_cuando
 * @property string $loans_observacion
 * @property string $loans_fecha
 * @property string $loans_estado
 * @property string $created_at
 * @property string $updated_at
 * @property string $deleted_at
 * @property ItemLoan[] $itemLoans
 */
class Loans extends Model
{
    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = true;
    protected $primaryKey = 'id';
    /**
     * @var array
     */
    protected $fillable = [
        'id',
        'user_creador',
        'user_recomendacion',
        'user_customer',
        'user_cobrador',
        'loans_nombre',
        'loans_apellido_uno',
        'loans_apellido_dos',
        'loans_tipo_documento',
        'loans_documento',
        'loans_fecha_nacimiento',
        'loans_ciudad',
        'loans_barrio',
        'loans_direccion',
        'loans_intereses',
        'loans_cuotas',
        'loans_valor_prestado',
        'loans_cuando',
        'loans_observacion',
        'loans_fecha',
        'loans_estado',
        'loans_inicio_pago',
        'loans_pago_prestado',
        'loans_pago_interes',
        'loans_fecha_ultimo_pago',
        'loans_intereses_recaudar',
        'loans_celular',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function itemLoans()
    {
        return $this->hasMany('App\Models\ItemLoan', 'loans_codigo');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function userCobrador()
    {
        return $this->belongsTo('App\Models\User', 'user_cobrador');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function userCreador()
    {
        return $this->belongsTo('App\Models\User', 'user_creador');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function userCustomer()
    {
        return $this->belongsTo('App\Models\User', 'user_customer');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function userRecomendacion()
    {
        return $this->belongsTo('App\Models\User', 'user_recomendacion');
    }
}
