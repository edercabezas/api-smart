<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $loans_codigo
 * @property integer $itemloans_cuota
 * @property integer $itemloans_valor_cuota
 * @property integer $itemloans_iteres
 * @property integer $itemloans_interes_canelado
 * @property integer $itemloans_cuota_cancelada
 * @property string $itemloans_status
 * @property string $itemloass_observacion
 * @property string $itemloans_fecha_pago
 * @property string $itemloans_aprobador
 * @property string $created_at
 * @property string $updated_at
 * @property string $deleted_at
 * @property Loan $loan
 */
class ItemLoans extends Model
{
    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    /**
     * @var array
     */
    protected $fillable = [
        'loans_codigo',
        'itemloans_cuota',
        'itemloans_valor_cuota',
        'itemloans_iteres',
        'itemloans_status',
        'itemloass_observacion',
        'itemloans_fecha_pago',
        'itemloans_aprobador',
        'item_loans_cuando_pago',
        'itemloans_interes_canelado',
        'itemloans_cuota_cancelada',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function loan()
    {
        return $this->belongsTo('App\Models\Loan', 'loans_codigo');
    }
}
