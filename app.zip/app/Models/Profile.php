<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use App\Transformers\V1\Clinic\ClinicTransformer;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Consultorio
 *
 * @property int $id
 * @property string $name
 * @property string $address
 * @property string $phone
 * @property Carbon $created_at
 * @property Carbon $updated_at
 *
 * @property Collection|Doctor[] $doctors
 *
 * @package App\Models
 */
class Profile extends Model
{
    use HasFactory, SoftDeletes;

    public $timestamps = true;

	protected $table = 'profile';
	protected $fillable = [
		'name',
		'address',
		'phone',
        'url_site'
	];

//    public $transformer = ClinicTransformer::class;

	public function itemMenuProfile()
	{
		return $this->hasMany(ItemMenu::class);
	}

    public function users()
    {
        return $this->hasMany(User::class);
    }



}
