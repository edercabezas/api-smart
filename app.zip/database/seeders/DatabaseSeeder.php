<?php

namespace Database\Seeders;


use App\Models\Profile;
use App\Models\Menu;
use App\Models\ItemMenu;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        Profile::factory(5)->create();

        Menu::factory(5)->create();
        ItemMenu::factory(5)->create();

        User::factory()->create(['email' => 'admin@admin.com']);
        User::factory(5)->create();

    }
}
