<?php

namespace Database\Factories;

use App\Models\ItemMenu;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<ItemMenu>
 */
class ItemMenuFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'item_menu_profile' => fake()->numberBetween(1, 3),
            'item_menu_menu' => fake()->numberBetween(1, 3),
            'clinic_id' => ItemMenu::factory()->create()->id
        ];
    }
}
