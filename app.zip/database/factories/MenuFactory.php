<?php

namespace Database\Factories;

use App\Models\Menu;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Menu>
 */
class MenuFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'menu_name' => fake()->lastName,
            'menu_prefix' => fake()->lastName,
            'menu_url' => fake()->lastName,
            'id' => Menu::factory()->create()->id
        ];
    }
}
